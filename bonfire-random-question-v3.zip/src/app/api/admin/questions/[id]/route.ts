import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdminApi } from "@/lib/session";
import { centralDateStringToUTC } from "@/lib/bonfire";

export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  if (!(await requireAdminApi())) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const body = await req.json().catch(() => null);
  const { type, format, prompt, options, correctIndex, explanation, logsReward, activeDate } = body || {};

  const data: Record<string, unknown> = {};
  if (type && ["DAILY", "WEEKLY", "BONUS", "RANDOM"].includes(type)) data.type = type;
  if (format && ["MULTIPLE_CHOICE", "TRUE_FALSE"].includes(format)) data.format = format;
  if (prompt) data.prompt = prompt;
  if (Array.isArray(options)) data.options = options;
  if (typeof correctIndex === "number") data.correctIndex = correctIndex;
  if (explanation !== undefined) data.explanation = typeof explanation === "string" ? explanation || null : null;
  if (typeof logsReward === "number") data.logsReward = logsReward;
  if (activeDate) data.activeDate = centralDateStringToUTC(activeDate);
  // Bonus questions always award exactly 3 logs, regardless of what was
  // submitted — enforced here too, not just in the admin form UI.
  if (data.type === "BONUS") data.logsReward = 3;

  const question = await prisma.question.update({ where: { id: params.id }, data });
  return NextResponse.json({ question });
}

export async function DELETE(_req: Request, { params }: { params: { id: string } }) {
  if (!(await requireAdminApi())) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  await prisma.question.delete({ where: { id: params.id } });
  return NextResponse.json({ ok: true });
}
