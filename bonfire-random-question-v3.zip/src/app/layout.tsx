import type { Metadata } from "next";
import { Inter } from "next/font/google";
import AmbientSparks from "@/components/AmbientSparks";
import "./globals.css";

// One professional sans-serif for everything — headings are differentiated
// by weight/size, not by switching to a separate display face. The earlier
// rounded display font (Baloo 2) read as playful/consumer-app rather than
// something you'd want in front of company leadership.
const inter = Inter({ subsets: ["latin"], variable: "--font-body" });

export const metadata: Metadata = {
  title: "Sun Country Q3 Bonfire Challenge",
  description: "Answer questions, earn logs, build the biggest bonfire.",
  // Deliberately NOT declaring `icons` here. Next.js gives an explicit
  // metadata.icons entry priority over the src/app/icon.svg file-convention
  // route — so having both means the convention-based route stops being
  // served, and the explicit <link> ends up pointing at a URL that 404s.
  // (That's exactly what broke the favicon last time.) Pick one mechanism;
  // the file convention alone is sufficient and simpler.
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${inter.variable}`} style={{ "--font-display": "var(--font-body)" } as React.CSSProperties}>
      <body className="font-body antialiased">
        <AmbientSparks />
        {children}
      </body>
    </html>
  );
}
