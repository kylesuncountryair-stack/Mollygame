"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { CalendarDays, CalendarRange, Check, Dices, Flame, Gift, HelpCircle, Sparkles, ThumbsDown, ThumbsUp, X } from "lucide-react";
import Badge from "./Badge";
import Confetti from "./Confetti";
import TierUpBanner from "./TierUpBanner";
import WrongAnswerModal from "./WrongAnswerModal";
import StreakBonusModal from "./StreakBonusModal";
import BonusUnlockedModal from "./BonusUnlockedModal";
import RandomQuestionUnlockedModal from "./RandomQuestionUnlockedModal";

type Answered = { selectedIndex: number; isCorrect: boolean; logsAwarded: number } | null;
type TierUp = { label: string } | null;
type SparkChain = { friendName: string; bonus: number } | null;
type WrongAnswerInfo = { correctIndex: number; explanation: string | null } | null;
type StreakBonus = { count: number; bonus: number } | null;
type BonusUnlocked = { id: string; prompt: string } | null;
type RandomUnlocked = { id: string; prompt: string; logsReward: number } | null;

export type QuestionData = {
  id: string;
  type: "DAILY" | "WEEKLY" | "BONUS" | "RANDOM";
  format?: "MULTIPLE_CHOICE" | "TRUE_FALSE";
  prompt: string;
  options: string[];
  logsReward: number;
  answered: Answered;
} | null;

export default function QuestionCard({ question }: { question: QuestionData }) {
  const router = useRouter();
  const [selected, setSelected] = useState<number | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [result, setResult] = useState<Answered>(question?.answered ?? null);
  const [error, setError] = useState("");
  // Only true right after a fresh submission in this session — keeps the
  // confetti/tier-up celebration from replaying every time the page loads
  // and finds a question that was already answered earlier.
  const [justAnswered, setJustAnswered] = useState(false);
  const [tierUp, setTierUp] = useState<TierUp>(null);
  const [sparkChain, setSparkChain] = useState<SparkChain>(null);
  const [wrongAnswer, setWrongAnswer] = useState<WrongAnswerInfo>(null);
  const [streakBonus, setStreakBonus] = useState<StreakBonus>(null);
  const [bonusUnlocked, setBonusUnlocked] = useState<BonusUnlocked>(null);
  const [randomUnlocked, setRandomUnlocked] = useState<RandomUnlocked>(null);
  // The correct/incorrect banner only shows right after a fresh submission
  // in this session, and fades out on its own after 30 seconds. It starts
  // hidden (not visible) on mount — including when the server tells us this
  // question was already answered earlier — so it doesn't pop back up every
  // time the page is refreshed, you log back in, or you revisit the
  // dashboard tab. Once it's gone, it stays gone; the checkmark/x on the
  // selected option is enough of a reminder after that.
  const [bannerVisible, setBannerVisible] = useState(false);
  // Answered questions shouldn't linger on the dashboard and clutter it up.
  // `dismissed` starts true immediately (before first paint) for anything
  // that was ALREADY answered when the page loaded — it just never
  // appears, no animation needed. For a question answered fresh in this
  // session, we let the celebration (banner/confetti/popups) play out
  // first, then collapse and remove the card a few seconds later.
  const [collapsing, setCollapsing] = useState(false);
  const [dismissed, setDismissed] = useState(() => !!question?.answered);

  useEffect(() => {
    if (!justAnswered || !result) return;
    setBannerVisible(true);
    const timer = setTimeout(() => setBannerVisible(false), 30000);
    return () => clearTimeout(timer);
  }, [justAnswered, result]);

  // Once any freshly-triggered popups have all been closed (or never
  // opened), give the player a few seconds to read the plain correct/wrong
  // banner, then start collapsing the card away.
  useEffect(() => {
    if (!justAnswered || !result) return;
    if (tierUp || streakBonus || wrongAnswer || bonusUnlocked || randomUnlocked) return;
    const timer = setTimeout(() => setCollapsing(true), 3500);
    return () => clearTimeout(timer);
  }, [justAnswered, result, tierUp, streakBonus, wrongAnswer, bonusUnlocked, randomUnlocked]);

  // Let the collapse transition finish playing before fully removing the
  // card from the layout.
  useEffect(() => {
    if (!collapsing) return;
    const timer = setTimeout(() => setDismissed(true), 500);
    return () => clearTimeout(timer);
  }, [collapsing]);

  if (dismissed) return null;

  if (!question) {
    return (
      <div className="flex flex-col items-center gap-2 rounded-2xl border border-dashed border-ash-700 bg-bg-card/50 p-6 text-center text-ash-500">
        <HelpCircle className="h-6 w-6 text-ash-600" />
        <p>No question is live right now &mdash; check back soon.</p>
      </div>
    );
  }

  const badgeConfig =
    question.type === "WEEKLY"
      ? { tone: "gold" as const, Icon: CalendarRange, label: "Weekly Question" }
      : question.type === "BONUS"
        ? { tone: "navy" as const, Icon: Gift, label: "Bonus Question" }
        : question.type === "RANDOM"
          ? { tone: "success" as const, Icon: Dices, label: "Random Question" }
          : { tone: "ember" as const, Icon: CalendarDays, label: "Daily Question" };

  async function submit() {
    if (selected === null) return;
    setSubmitting(true);
    setError("");
    try {
      const res = await fetch(`/api/questions/${question!.id}/answer`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ selectedIndex: selected }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Something went wrong.");
        return;
      }
      setResult({ selectedIndex: selected, isCorrect: data.isCorrect, logsAwarded: data.logsAwarded });
      setJustAnswered(true);
      if (data.tierUp) setTierUp({ label: data.tierUp.label });
      if (data.sparkChain) setSparkChain(data.sparkChain);
      if (!data.isCorrect) setWrongAnswer({ correctIndex: data.correctIndex, explanation: data.explanation ?? null });
      if (data.streakBonus) setStreakBonus(data.streakBonus);
      if (data.bonusUnlocked) setBonusUnlocked(data.bonusUnlocked);
      if (data.randomUnlocked) setRandomUnlocked(data.randomUnlocked);
      router.refresh();
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div
      className={`overflow-hidden transition-all duration-500 ease-out ${
        collapsing ? "max-h-0 opacity-0" : "max-h-[2000px] opacity-100"
      }`}
    >
    <div className="animate-rise rounded-2xl border border-ash-900 bg-bg-card shadow-card p-6">
      <div className="mb-4 flex items-center justify-between">
        <Badge tone={badgeConfig.tone}>
          <badgeConfig.Icon className="h-3 w-3" />
          {badgeConfig.label}
        </Badge>
        {result ? (
          <span
            className={`flex items-center gap-1 text-sm font-medium ${
              result.isCorrect ? "text-emerald-400" : "text-rose-400"
            }`}
          >
            {result.isCorrect ? <Check className="h-4 w-4" /> : <X className="h-4 w-4" />}
            {result.isCorrect ? `Answered · +${result.logsAwarded} logs` : "Answered"}
          </span>
        ) : (
          <span className="flex items-center gap-1 text-sm text-ember-300">
            <Flame className="h-4 w-4" /> +{question.logsReward} logs
          </span>
        )}
      </div>

      <p className="mb-5 font-display text-lg font-semibold text-ash-100">{question.prompt}</p>

      {question.format === "TRUE_FALSE" ? (
        <div className="grid grid-cols-2 gap-3">
          {question.options.map((opt, i) => {
            const isSelected = (result ? result.selectedIndex : selected) === i;
            const showCorrectness = !!result;
            const isCorrectOption = i === result?.selectedIndex && result?.isCorrect;
            const isWrongOption = i === result?.selectedIndex && result && !result.isCorrect;
            const Icon = i === 0 ? ThumbsUp : ThumbsDown;

            return (
              <button
                key={i}
                disabled={!!result || submitting}
                onClick={() => setSelected(i)}
                className={`flex flex-col items-center gap-2 rounded-xl border px-4 py-5 text-sm font-semibold transition-colors ${
                  isSelected
                    ? "border-ember-500 bg-ember-500/10 text-ash-100"
                    : "border-ash-800 bg-bg-panel text-ash-300 hover:border-ash-700"
                } ${result ? "cursor-default" : "cursor-pointer"}`}
              >
                <Icon className="h-5 w-5" />
                <span className="flex items-center gap-1.5">
                  {opt}
                  {showCorrectness && isCorrectOption && <Check className="h-4 w-4 text-emerald-400" />}
                  {showCorrectness && isWrongOption && <X className="h-4 w-4 text-rose-400" />}
                </span>
              </button>
            );
          })}
        </div>
      ) : (
        <div className="space-y-2">
          {question.options.map((opt, i) => {
            const isSelected = (result ? result.selectedIndex : selected) === i;
            const showCorrectness = !!result;
            const isCorrectOption = i === result?.selectedIndex && result?.isCorrect;
            const isWrongOption = i === result?.selectedIndex && result && !result.isCorrect;

            return (
              <button
                key={i}
                disabled={!!result || submitting}
                onClick={() => setSelected(i)}
                className={`flex w-full items-center justify-between rounded-xl border px-4 py-3 text-left text-sm transition-colors ${
                  isSelected
                    ? "border-ember-500 bg-ember-500/10 text-ash-100"
                    : "border-ash-800 bg-bg-panel text-ash-300 hover:border-ash-700"
                } ${result ? "cursor-default" : "cursor-pointer"}`}
              >
                <span>{opt}</span>
                {showCorrectness && isCorrectOption && <Check className="h-4 w-4 text-emerald-400" />}
                {showCorrectness && isWrongOption && <X className="h-4 w-4 text-rose-400" />}
              </button>
            );
          })}
        </div>
      )}

      {error && <p className="mt-3 text-sm text-rose-400">{error}</p>}

      {!result ? (
        <button
          onClick={submit}
          disabled={selected === null || submitting}
          className="mt-5 w-full rounded-lg bg-ember-500 py-2.5 font-semibold text-white transition-colors hover:bg-ember-600 disabled:cursor-not-allowed disabled:opacity-40"
        >
          {submitting ? "Submitting..." : "Submit Answer"}
        </button>
      ) : result.isCorrect ? (
        <div
          className={`relative overflow-hidden rounded-xl bg-emerald-500/10 transition-all duration-500 ease-out ${
            bannerVisible ? "mt-5 max-h-40 px-4 py-5 opacity-100" : "mt-0 max-h-0 px-4 py-0 opacity-0"
          }`}
        >
          {justAnswered && bannerVisible && <Confetti />}
          <div className="relative flex flex-col items-center gap-2">
            <div className="flex h-11 w-11 items-center justify-center rounded-full bg-bg-panel shadow-glow">
              <Check className="h-5 w-5 text-emerald-400" />
            </div>
            <div className="text-center font-medium text-emerald-300">
              Correct! +{result.logsAwarded} logs added to your bonfire.
            </div>
            {justAnswered && sparkChain && (
              <div className="flex items-center gap-1.5 rounded-full bg-gold-500/15 px-3 py-1 text-xs font-medium text-gold-300">
                <Sparkles className="h-3.5 w-3.5" />
                Spark chain with {sparkChain.friendName}! +{sparkChain.bonus} bonus log for you both.
              </div>
            )}
          </div>
        </div>
      ) : (
        <div
          className={`overflow-hidden rounded-xl bg-rose-500/10 text-center font-medium text-rose-300 transition-all duration-500 ease-out ${
            bannerVisible ? "mt-5 max-h-40 px-4 py-3 opacity-100" : "mt-0 max-h-0 px-4 py-0 opacity-0"
          }`}
        >
          Not quite — better luck on the next one.
        </div>
      )}

      {justAnswered && tierUp && <TierUpBanner tier={tierUp} onClose={() => setTierUp(null)} />}

      {justAnswered && !tierUp && streakBonus && (
        <StreakBonusModal count={streakBonus.count} bonus={streakBonus.bonus} onClose={() => setStreakBonus(null)} />
      )}

      {justAnswered && wrongAnswer && (
        <WrongAnswerModal
          correctAnswer={question.options[wrongAnswer.correctIndex]}
          explanation={wrongAnswer.explanation}
          onClose={() => setWrongAnswer(null)}
        />
      )}

      {/* Shown last so it doesn't overlap the tier-up/streak/wrong-answer
          popups — bonusUnlocked can fire alongside any of those since it's
          based on being first today, independent of whether this specific
          answer was correct. */}
      {justAnswered && !tierUp && !streakBonus && !wrongAnswer && bonusUnlocked && (
        <BonusUnlockedModal onClose={() => setBonusUnlocked(null)} />
      )}

      {/* Same reasoning as bonusUnlocked above — shown last, and only once
          nothing higher-priority is showing. randomUnlocked fires when this
          DAILY answer was correct and won the player one of today's random
          slots. */}
      {justAnswered && !tierUp && !streakBonus && !wrongAnswer && !bonusUnlocked && randomUnlocked && (
        <RandomQuestionUnlockedModal logsReward={randomUnlocked.logsReward} onClose={() => setRandomUnlocked(null)} />
      )}
    </div>
    </div>
  );
}
